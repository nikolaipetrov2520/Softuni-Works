﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SoftUni.Models
{
    public partial class VEmployeesSalary
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public decimal Salary { get; set; }
    }
}
